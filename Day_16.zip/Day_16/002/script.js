var arrayOne = [20, 40, 50, 10, 60];
var arrayMin = Math.min(...arrayOne);
var arrayMax = Math.max(...arrayOne);
console.log("Minimum Number in a Array: " + [arrayMin]);
console.log("Maximum Number in a Array: " + [arrayMax]);
