let employeeDetails = {
  empName: "James",
  id: "001",
  designation: "Database Developer",
  address: "UK,England",
};
let employeeDetails2 = {
  empName: "Robin",
  id: "002",
  designation: "IT Programmer",
  address: "Austria",
};

let employeeDetails3 = {
  empName: "Wayn",
  id: "003",
  designation: "SE",
  address: "UK,Scotland",
};

console.log([employeeDetails.empName,employeeDetails2.empName,employeeDetails3.empName]);
