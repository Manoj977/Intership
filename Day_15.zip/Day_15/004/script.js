let space = "";
for (let num1 = 1; num1 <= 5; num1++) {
  for (let num2 = 1; num2 <= num1; num2++) {
    space += num2;
  }
  space += "\n";
}
console.log(space);
