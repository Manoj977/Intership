import React from 'react'

const ContactUs = () => {
  return (
    <div className="content container">ContactUs</div>
  )
}

export default ContactUs