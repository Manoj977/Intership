import React from "react";

const Header = (props) => {
  return (
    <div
      style={{
        margin: "20px 0px",
        width: "80vw",
        height: "90vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-evenly",
        border: "1px solid",
        fontSize: "48px",
        boxShadow: `2px 3px 3px #CCC`,
        background: props.bgColor,
      }}
    >
      Header
      <select
        onChange={(e) => {
          props.setBgColor(e.target.value);
        }}
        style={{
          width: "120px",
          background: "White",
        }}
      >
        <option selected={props.bgColor === "Beige"} value="Beige">
          Beige
        </option>
        <option selected={props.bgColor === "cadetBlue"} value="cadetBlue">
        cadetBlue
        </option>
        <option selected={props.bgColor === "gainsBoro"} value="gainsBoro">
        gainsBoro
        </option>
      </select>
    </div>
  );
};

export default Header;
