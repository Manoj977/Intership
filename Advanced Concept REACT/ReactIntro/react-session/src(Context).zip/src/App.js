import React, { useState } from "react";
import "./App.css";
import Header from "./Header";
const App = () => {
  const [bgColor, setBgColor] = useState("red");
  return (
    <div className="container">
      <Header bgColor={bgColor} setBgColor={setBgColor}/>
    </div>
  );
};

export default App;
