import React from "react";
import Data from "./Data/Data";
const Home = () => {
  return (
    <div className="container">
      <h1 className="heading">Data Fetch</h1><hr/>
      <Data/>
    </div>
  );
};

export default Home;
