import axios from "axios";

//instance Create
const axiosData = axios.create({ baseURL: "https:randomuser.me/" });

//service Method
const getRandomUsers = () => {
  return axiosData
    .get(
      "api/?results=100", //give path
      {
        headers: {
          "context-type": "application/json", //Application type
        },
      }
    )
    .then((res) => {
      return res.data;
    })
    .catch((e) => {
      throw e;
    });
};

export { getRandomUsers };
