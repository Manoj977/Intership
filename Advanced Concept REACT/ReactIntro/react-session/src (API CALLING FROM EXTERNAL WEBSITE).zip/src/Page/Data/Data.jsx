import React, { useEffect, useState } from "react";
import { getRandomUsers } from "../Api/Api.jsx";
const Data = () => {
  const [usersData, setUsersData] = useState([]);
  const [loading, setLoading] = useState(false);
  //to call use useEffect to place in [component did mount]
  useEffect(() => {
    getData();
  }, []);
  const getData = async () => {
    setLoading(true);
    const data = await getRandomUsers(); //Api function called
    const dataStore = [];
    data.results.find((i) => {
      //
      const dataObject = {
        name: `${i.name.title}   ${i.name.first}   ${i.name.last}`,
        email: i.email,
        photo: i.picture.medium,
        age: i.dob.age,
        phone: i.phone,
      };
      dataStore.push(dataObject);
    });
    setLoading(false);
    setUsersData(dataStore);
  };
  return (
    <div>
      {/* to display the api function in table */}
      <>
        {loading && (
          <div>
            <button type="button" class="bg-indigo-500 ..." disabled>
              <svg
                class="animate-spin h-5 w-5 mr-3 ..."
                viewBox="0 0 24 24"
              ></svg>
              Processing...
            </button>
          </div>
        )}
        {!loading && (
          <table>
            <thead>
              <tr>
                <td>
                  <h4>Photo</h4>
                </td>
                <td>
                  <h4>Name</h4>
                </td>
                <td>
                  <h4>Email</h4>
                </td>
                <td>
                  <h4>DOB</h4>
                </td>
                <td>
                  <h4>Phone</h4>
                </td>
              </tr>
            </thead>
            <tbody>
              {usersData.map((item, index) => (
                <tr key={index}>
                  <td>
                    <img src={item.photo} alt="profile-img" />
                  </td>
                  <td>{item.name}</td>
                  <td>{item.email}</td>
                  <td>{item.age}</td>
                  <td>{item.phone}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </>
    </div>
  );
};

export default Data;
