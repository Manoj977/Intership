import React from "react";
import Home from "./Page/Home";
import "./App.css";
import "./Styles.css"
const App = () => {
  return (
    <div>
      <Home />
    </div>
  );
};

export default App;
