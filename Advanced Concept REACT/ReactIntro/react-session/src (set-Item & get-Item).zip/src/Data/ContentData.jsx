const Data = {
  products: [
    {
      ProductID: "41032895",
      ProductImage:
        "https://rukminim1.flixcart.com/image/416/416/l3t2fm80/mobile/v/0/b/-original-imageu8ctfzzstqp.jpeg?q=70",
      ProductName: "realme 9 (Stargaze White, 128 GB) (6 GB RAM)",
      ProductPrice: "16999",
    },
    {
      ProductID: "41032896",
      ProductImage:
        "https://rukminim1.flixcart.com/image/416/416/ky7lci80/mobile/t/x/j/-original-imagahvge92r5fmm.jpeg?q=70",
      ProductName: "ASUS ROG 5s (Black, 128 GB)  (8 GB RAM)",
      ProductPrice: "49999",
    },
    {
      ProductID: "41032897",
      ProductImage:
        "https://rukminim1.flixcart.com/image/416/416/l0igvww0/mobile/j/d/g/-original-imagcafg6hbeeqwf.jpeg?q=70",
      ProductName: "POCO M4 Pro 5G (Cool Blue, 128 GB)  (6 GB RAM)",
      ProductPrice: "14999",
    },
    {
      ProductID: "41032898",
      ProductImage:
        "https://rukminim1.flixcart.com/image/416/416/kn4xhu80/mobile/r/5/5/f19-cph2219-oppo-original-imagfvj5usebqhh4.jpeg?q=70 ",
      ProductName: "OPPO F19 (Midnight Blue, 128 GB)  (6 GB RAM)",
      ProductPrice: "14990",
    },
    {
      ProductID: "41032899",
      ProductImage:
        "https://rukminim1.flixcart.com/image/416/416/kwv0djk0/mobile/g/h/4/note-11t-21091116ai-mzb0a8qin-redmi-original-imag9g37hzxggjgg.jpeg?q=70",
      ProductName: "REDMI Note 11T 5G (Stardust White, 128 GB)  (8 GB RAM)",
      ProductPrice: "17736",
    },
    {
      ProductID: "41032900",
      ProductImage:
        "https://rukminim1.flixcart.com/image/416/416/xif0q/mobile/9/q/j/-original-imagk4nzwhudqhcz.jpeg?q=70",
      ProductName: "REDMI 10 (Midnight Black, 64 GB)  (4 GB RAM)",
      ProductPrice: "10999",
    },
  ],
};

export default Data;
