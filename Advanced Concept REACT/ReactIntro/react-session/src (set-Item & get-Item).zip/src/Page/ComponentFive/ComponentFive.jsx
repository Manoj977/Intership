import React from "react";
import "../../../src/Style.css";
const ComponentFive = () => {
  return (
    <div className="component-home">
      <div className="About">About Component</div>
    </div>
  );
};

export default ComponentFive;
