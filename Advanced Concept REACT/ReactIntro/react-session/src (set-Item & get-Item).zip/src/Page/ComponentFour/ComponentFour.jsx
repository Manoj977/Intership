import React from "react";
import "../../../src/Style.css";
const ComponentFour = () => {
  return (
    <div className="component-home">
      <div className="Account">Account Component</div>
    </div>
  );
};

export default ComponentFour;
