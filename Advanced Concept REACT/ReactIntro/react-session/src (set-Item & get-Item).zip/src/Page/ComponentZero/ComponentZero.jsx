import React from "react";

const ComponentZero = () => {
  return (
    <div className="component-home">
      <div className="Account">Home Component</div>
    </div>
  );
};

export default ComponentZero;
