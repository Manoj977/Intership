import React from "react";

const About = () => {
  return <div className="content container">About</div>;
};

export default About;
