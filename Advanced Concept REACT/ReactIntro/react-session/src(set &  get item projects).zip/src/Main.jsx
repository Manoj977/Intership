import React from "react";

const Main = () => {
  return <div className="content">Main</div>;
};

export default Main;
