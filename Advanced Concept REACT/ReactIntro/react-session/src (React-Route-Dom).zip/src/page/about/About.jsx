import React from "react";

const About = () => {
  return (
    <div>
      <br />
      <hr />
      About
    </div>
  );
};

export default About;
