const Data = [
  {
    OrderID: "9862365",
    ProductName: "Zebronics 2.1 Channel",
    Price: "₹7899",
    image: "https://picsum.photos/200/301",
  },
  {
    OrderID: "8626459",
    ProductName: "Sandisk 32GB UFS 3.0",
    Price: "₹699 ",
    image: "https://picsum.photos/200/302",
  },
  {
    OrderID: "8597562",
    ProductName: "Sony Dolby Atmos 2.1 Channel",
    Price: "₹1699 ",
    image: "https://picsum.photos/200/303",
  },
  {
    OrderID: "7689532",
    ProductName: "Parasonic 25L Water Heater",
    Price: "₹10999 ",
    image: "https://picsum.photos/200/304",
  },
];

export default Data;
