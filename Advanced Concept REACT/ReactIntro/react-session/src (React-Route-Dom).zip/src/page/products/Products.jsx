import React from "react";

const Products = () => {
  return (
    <div>
      <br />
      <hr />
      Products
    </div>
  );
};

export default Products;
