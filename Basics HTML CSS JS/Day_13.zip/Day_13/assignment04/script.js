//04 Write a program to check if the number is odd or even:

var number = prompt("Enter a number");
if (number % 2 == 0) {
  alert(number + " Number is Even");
} else {
  alert(number + " Number is Odd");
}
