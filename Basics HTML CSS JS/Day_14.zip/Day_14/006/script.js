var orgin = new Date("01/02/1970 05:30:00");
const ms = orgin.getTime();

// let dates = parseInt(new Date().getDate());
// let months = parseInt(new Date().getMonth() + 1);
// let years = parseInt(new Date().getFullYear());

let user_date = prompt("Enter your Date of birth(DD-MM-YYYY):").toString();
let user_date_day = parseInt(user_date.slice(0, 2));
let user_date_month = parseInt(user_date.slice(3, 5));
let user_date_year = parseInt(user_date.slice(6, 10));

// let d = Math.abs(date - user_date_day);
// let m = Math.abs(month - user_date_month);
// let y = Math.abs(year - user_date_year);

var calc =
  (new Date() - new Date(user_date_year, user_date_month, user_date_day)) / ms;
console.log(calc.toFixed(2));

//   console.log("updated: "+new Date(years-months-dates));
