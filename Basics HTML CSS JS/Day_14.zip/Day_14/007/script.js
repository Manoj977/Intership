var num_one = parseInt(prompt("Enter First number:"));
var num_two = parseInt(prompt("Enter Second number: "));
var total = num_one + num_two;
if (total >= 100) alert("false");
else alert("true");
