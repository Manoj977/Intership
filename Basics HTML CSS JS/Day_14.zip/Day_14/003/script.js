var number = Math.random()*10 +1;
let num =Math.floor(number);
if (num % 3 ==0){
    console.log("You Win "+num);
}
else{
    console.log("Sorry You Loose "+num);
}
