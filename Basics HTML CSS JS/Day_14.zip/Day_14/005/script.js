var min = parseFloat(prompt("Enter Minutes:")).toFixed(2);
var sec = min * 60;
alert("Remaining " + sec + " Seconds Left");
