let rand= (Math.random()*1000000);
console.log("Your 6 digit OTP is: "+rand.toFixed());