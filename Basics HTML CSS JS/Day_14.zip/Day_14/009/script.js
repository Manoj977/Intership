let employeeDetails = {
  firstName: "Manoj",
  lastName: "Saravanan",
  gender: "Male",
  location: "Tirunelveli,Tamilnadu",
};
var fullName = (employeeDetails.firstName).concat(" ",employeeDetails.lastName);
console.log("FullName: "+fullName);
